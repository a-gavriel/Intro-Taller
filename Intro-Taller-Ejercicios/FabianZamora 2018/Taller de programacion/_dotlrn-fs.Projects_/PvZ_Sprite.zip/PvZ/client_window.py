import pygame
import threading
import socket
from board import *
from button import *

class ClientWindow:

    # UI
    surface = None
    width = 600
    height = 600
    btn_done = None

    # Socket
    socket_c = None
    running = True
    
    # Game logic
    board = None
        
    def start(self):
        self.set_initial_ui()
        self.start_socket_async()
        self.board = Board()

    def stop(self):
        if self.socket_c != None:
            self.socket_c.close()

    def set_initial_ui(self):
        pygame.display.set_caption('PvZ Duel - Client')
        self.surface = pygame.display.set_mode((self.width,self.height))
        print(type(self.surface))
        self.surface.fill(white)
        self.btn_done = Button(100, 100, "Listo")

    def start_socket_async(self):
        t = threading.Thread(target=self.start_socket)
        t.start()

    def start_socket(self):
        self.socket_c = socket.socket()
        self.socket_c.connect(("172.20.10.7", 5557))
        while self.running:
            read = self.socket_c.recv(1024).decode()
            print("Received:", read)
            pass

    def btn_done_click(self):
        if self.socket_c != None:
            self.socket_c.send("Z001;01;02".encode())

    def dibujese(self):
        self.btn_done.draw(self.surface)

    def main_loop_event(self, event):
        mouse_x = pygame.mouse.get_pos()[0]
        mouse_y = pygame.mouse.get_pos()[1]
        
        # Detecta el movimiento del mouse para cambiar el color del boton
        if event.type == pygame.MOUSEMOTION:
            self.btn_done.check_click(mouse_x, mouse_y)

        # Detecta el click
        if event.type == pygame.MOUSEBUTTONUP:
            if self.btn_done.check_click(mouse_x, mouse_y):
                self.btn_done_click()                
                return 1
        return 0
        
        
        
