import pygame
from pygame.locals import *

class PersonajeSprite(pygame.sprite.Sprite):

	pos_x = 0
	pos_y = 0
	rect = None
	image = None

	def __init__(self, imagen_url):
		pygame.sprite.Sprite.__init__(self)
		self.image = pygame.image.load(imagen_url).convert_alpha()
		self.rect = self.image.get_rect()		

	def dibujese(self, surface):
		self.rect.centerx = self.pos_x
		self.rect.centery = self.pos_y
		surface.blit(self.image, self.rect)