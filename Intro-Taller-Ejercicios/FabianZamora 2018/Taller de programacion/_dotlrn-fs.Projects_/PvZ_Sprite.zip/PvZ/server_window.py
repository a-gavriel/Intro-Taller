import pygame
import threading
import socket
from button import *
from board import *
from personaje import *

class ServerWindow:

    # UI
    surface = None # esta es la ventana sobre la cual se dibuja
    width = 400
    height = 400    
    btn_done = None

    # Socket
    running = True
    socket_s = None
    socket_c = None
    img_fondo = None

    # Game logic
    board = None

    # Personaje de prueba
    personaje = None
    
    # Se llama desde main.py cuando se crea la ventana
    def start(self):        
        self.set_initial_ui()
        self.start_socket_async()
        self.board = Board()
        self.personaje = Personaje("plant.png")

    def stop(self):
        self.running = False
        if self.socket_s != None:
            self.socket_s.close()
        if self.socket_c != None:
            self.socket_c.close()

    def set_initial_ui(self):
        pygame.display.set_caption('PvZ Duel - Server')
        self.surface = pygame.display.set_mode((self.width, self.height))
        self.img_fondo = pygame.image.load("fondo.png").convert_alpha()  
        self.img_fondo.get_rect().centerx = 200
        self.img_fondo.get_rect().centery = 200
        self.btn_done = Button(100, 100, "Listo")

    # Se utiliza para iniciar el socket en un hilo aparte
    def start_socket_async(self):
        t = threading.Thread(target=self.start_socket) # Crea un hilo y le dice que ejeucte el metodo start_socket
        t.start()

    # Crea un socket. Espera la conexion de un cliente. Lee constantemente de la conexion realizada.
    def start_socket(self):
        self.socket_s = socket.socket()
        self.socket_s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket_s.bind((socket.gethostbyname(socket.gethostname()), 5557))
        self.socket_s.listen(10)
        print("Esperando cliente:")
        self.socket_c, (host_c, puerto_c) = self.socket_s.accept()        
        print("Cliente conectado:")
        while self.running:            
            print("Leyendo del socket")
            try:
                read = self.socket_c.recv(1024).decode()
                print("Read:", read)
            except:
                print("Se cayo")        
    
    # Evento que se llama cuando se hace click en el boton de Done
    def btn_done_click(self):
        if self.socket_c != None:
            self.socket_c.send("Z002;01;02".encode())

    # Dibuja sus elementos en pantalla
    def dibujese(self):
        
        # PRIMERO dibuja el fondo
        self.surface.blit(self.img_fondo, self.img_fondo.get_rect())

        # DESPUES dibuja lo demas
        self.btn_done.draw(self.surface) # Boton de listo
        self.personaje.sprite.dibujese(self.surface) # El/Los personajes

    # Cuando el usuario hace un evento, se llama este metodo desde main.py
    def main_loop_event(self, event):

        # Toma la posicion del mouse
        mouse_x = pygame.mouse.get_pos()[0]
        mouse_y = pygame.mouse.get_pos()[1]

        if event.type == pygame.MOUSEMOTION:
            self.btn_done.check_click(mouse_x, mouse_y)

        elif event.type == pygame.MOUSEBUTTONUP:
            if self.btn_done.check_click(mouse_x, mouse_y):
                self.btn_done_click()
                return 1
            else:
                # Cambia la posicion donde se va a dibujar el personaje
                self.personaje.sprite.pos_x = mouse_x
                self.personaje.sprite.pos_y = mouse_y
        return 0
