from personaje_sprite import *

class Personaje:

	puntos_vida = 0
	puntos_ataque = 0
	codigo = None
	sprite = None

	def __init__(self, imagen_url):
		self.puntos_vida = 100
		self.puntos_ataque = 100
		self.codigo = "Fab01"		

		# Crea el sprite que se va a dibujar en pantalla
		self.sprite = PersonajeSprite(imagen_url)