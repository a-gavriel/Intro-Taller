import pygame
import threading
import socket
from button import *
from board import *

class ServerWindow:

    # UI
    surface = None
    width = 600
    height = 600    
    btn_done = None

    # Socket
    running = True
    socket_s = None
    socket_c = None

    # Game logic
    board = None
    
    # Se llama desde main.py cuando se crea la ventana
    def start(self):        
        self.set_initial_ui()
        self.start_socket_async()
        self.board = Board()

    def stop(self):
        self.running = False
        if self.socket_s != None:
            self.socket_s.close()
        if self.socket_c != None:
            self.socket_c.close()

    def set_initial_ui(self):
        pygame.display.set_caption('PvZ Duel - Server')
        self.surface = pygame.display.set_mode((self.width, self.height))
        self.surface.fill(white)
        self.btn_done = Button(100, 100, "Listo")

    # Se utiliza para iniciar el socket en un hilo aparte
    def start_socket_async(self):

        # Crea un hilo y le dice que ejeucte el metodo start_socket
        t = threading.Thread(target=self.start_socket)
        t.start()

    # Crea un socket. Espera la conexion de un cliente. Lee constantemente de la conexion realizada.
    def start_socket(self):
        self.socket_s = socket.socket()
        self.socket_s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.socket_s.bind((socket.gethostbyname(socket.gethostname()), 5557))
        self.socket_s.listen(10)
        print("Esperando cliente:")
        self.socket_c, (host_c, puerto_c) = self.socket_s.accept()        
        print("Cliente conectado:")
        while self.running:            
            print("Leyendo del socket")
            try:
                read = self.socket_c.recv(1024).decode()
                print("Read:", read)
            except:
                print("Se cayo")        
    
    def btn_done_click(self):
        if self.socket_c != None:
            self.socket_c.send("Z002;01;02".encode())

    def handle_event(self, event):
        mouse_x = pygame.mouse.get_pos()[0]
        mouse_y = pygame.mouse.get_pos()[1]
        self.btn_done.draw(self.surface)

        # Detecta el movimiento del mouse para cambiar el color del boton
        if event.type == pygame.MOUSEMOTION:
            self.btn_done.check_click(mouse_x, mouse_y)

        # Detecta el click
        if event.type == pygame.MOUSEBUTTONUP:
            if self.btn_done.check_click(mouse_x, mouse_y):
                self.btn_done_click()
                return 1
        return 0
