import pygame
from colors import *

class Button:
    pos_x = 100
    pos_y = 100
    height = 50
    width = 100
    text = "Button"    
    text_surface = None
    text_rect = None
    clicked = False

    def __init__(self, pos_x, pos_y, text):
        font = pygame.font.Font('freesansbold.ttf', 15)
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.text_surface = font.render(text, True, black)
        print(type(self.text_surface))
        self.text_rect = self.text_surface.get_rect()
        print(type(self.text_rect))
        self.text_rect.center = ((self.pos_x + self.width/2),(self.pos_y + self.height/2))

    def draw(self, display):
        if self.clicked:
            pygame.draw.rect(display, red,(self.pos_x,self.pos_y,self.width,self.height))
        else:
            pygame.draw.rect(display, blue,(self.pos_x,self.pos_y,self.width,self.height))
        display.blit(self.text_surface, self.text_rect)

    def check_click(self, mouse_x, mouse_y):
        self.clicked = False
        if self.pos_y <= mouse_y <= self.pos_y + self.height:
            if self.pos_x <= mouse_x <= self.pos_x + self.width:
                self.clicked = True
        return self.clicked
