class Board:

    matrix = []
    turn = 0
    turn_finished = False
    oponent_data = None

    def __init__(self):
        self.setup_matrix()
        
    def setup_matrix(self):
        for i in range(5):
            row = []
            for j in range(9):
                row.append(None)
            self.matrix.append(row)

    def finish_turn(self):
        self.done = True
        if self.oponent_data != None:
            self.sync_matrix()

    def set_oponent_data(self, data):
        self.oponent_data = data
        if self.done:
            self.sync_matrix()

    def sync_matrix(self):
        turn += 1
        turn_finished = False
        oponent_data = None

    def debug(self):
        for row in range(5):
            print("")
            for col in range(9):
                print(self.matrix[row][col], end="")
                print(" ", end="")
