
import pygame
from server_window import *
from start_window import *
from client_window import *
from colors import *

pygame.init()

# Ventanas
server_window = None
client_window = None
start_window = StartWindow()
start_window.start()

clock = pygame.time.Clock()
running = True
while running:
    for event in pygame.event.get():        
        if event.type == pygame.QUIT:
            running = False
            if server_window != None:
                server_window.stop()
            if client_window != None:
                client_window.stop()
        else:

            # Ventana principal
            if start_window != None:
                next_window = start_window.handle_event(event)
                if next_window == 1:
                    start_window = None
                    server_window = ServerWindow()
                    server_window.start()
                elif next_window == 2:
                    start_window = None
                    client_window = ClientWindow()
                    client_window.start()
                    
            # Ventana servidor
            elif server_window != None:
                server_window.handle_event(event)
                pass

            # Ventana cliente
            elif client_window != None:
                client_window.handle_event(event)
                pass

    pygame.display.update()
    clock.tick(60)

pygame.quit()
quit()
