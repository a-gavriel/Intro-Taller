"""
****************************

  Instituto Tecnologico de Costa Rica

    Ingenieria en Computadores

Version de Lenguaje de Python 3.5.1
Autor: Alexis Gavriel
Carné: 2016085662
Version 1.0
Fecha Ultima modificación: 27 Marzo 2016

Entradas: Lista con numeros enteros
Restricciones: No lista, lista con numeros no enteros
Salidas: Si en la lista todos los elementos son impares

****************************
"""
def todos_impar (Lista):
  if isinstance (Lista,list):
    if val(Lista):
      return xnum_impar(Lista)
    else:
      return "Un valor en la lista no es entero"
  else:
    return "Debe ingresar una lista"

def val(Lista):
  if Lista == []:
    return True
  elif not valE(Lista[0]):
    return False
  else:
    return val(Lista[1:])

def valE(X):
    if isinstance (X,int):
      return True
    else:
      return False

def xnum_impar (Lista):
  if Lista == []:
    return True
  elif Lista[0] %2 == 0:
    return False
  else:
    return xnum_impar(Lista[1:])
