#
#
"""
****************************

  Instituto Tecnologico de Costa Rica

    Ingenieria en Computadores

Version de Lenguaje de Python 3.5.1
Autor: Alexis Gavriel
Carné: 2016085662
Version 1.0
Fecha Ultima modificación: 27 mayo

Entradas: 2 Matrices
Restricciones: listas de listas que no son matrices , numeros no en base8
Salidas: suma de las matrices, los valores negativos los toma positivos tras sacarles el complemento
****************************
"""
#
#
def a_mas_bc15(A,B,C):
    x = cambio(A,len(A),len(A[0]),0,0)
    y = cambio(B,len(B),len(B[0]),0,0)
    C = suma (x,y,len(A),len(A[0]),0,0,[],[])
    return C

def cambio (Matriz,n,m,i,j):
    if n==i:
        return Matriz
    elif m ==j:
        return cambio(Matriz,n,m,i+1,0)
    elif Matriz[i][j]>=0:
        return cambio(Matriz,n,m,i,j+1)
    elif Matriz[i][j]<0:
        temp = str(abs(Matriz[i][j]))
        if len(temp) == 2:
            if temp[1]=='0':
                Matriz[i][j] = (7- int(temp) //10 ) *10
                return cambio(Matriz,n,m,i,j+1)
            else:
                Matriz[i][j] = (7-int(temp)//10) *10 +(8-int(temp)%10)
                return cambio(Matriz,n,m,i,j+1)
        elif len(temp) ==1:
            Matriz[i][j] = 7 - int(temp)
            return cambio(Matriz,n,m,i,j+1)
        else:
            return False
    else:
        return False

def suma(A,B,n,m,i,j,Vect,R):
    if n==i:
        return R
    elif m==j:
        R.append(Vect)
        return suma(A,B,n,m,i+1,0,[],R)
    else:
        Vect.append(A[i][j]+B[i][j])
        return suma(A,B,n,m,i,j+1,Vect,R)







        
