#
#
"""
****************************

  Instituto Tecnologico de Costa Rica

    Ingenieria en Computadores

Version de Lenguaje de Python 3.5.1
Autor: Alexis Gavriel
Carné: 2016085662
Version 1.0
Fecha Ultima modificación: 27 mayo

Entradas: 1 Matriz
Restricciones: numeros no en base8
Salidas: de los numeros de la matriz saca el complemento a los numeros negativos y los deja negativos
****************************
"""
#
#
def C7(c7):
    return c7_aux(c7,len(c7),len(c7[0]),0,0,[],[])

def c7_aux(Mat,n,m,i,j,V,R):
    if n==i:
        return R
    elif m==j:
        R.append(V)
        return c7_aux(Mat,m,n,i+1,0,[],R)
    elif Mat[i][j] >= 0:
        V.append(Mat[i][j])
        return c7_aux(Mat,m,n,i,j+1,V,R)
    elif Mat[i][j] < 0:
        V.append(conv(abs(Mat[i][j]),len(str(Mat[i][j]))))
        return c7_aux(Mat,m,n,i,j+1,V,R)
    else:
        return 'Error'

def conv(N,i): #se quito un argumento en exceso
    if i==1:
        return (7N)*-1
    elif i == 2:
        if N%10 == 0:
            return (7-N//10)*10*-1
        else:
            return ((7-N//10)*10 +(8-N%10))*-1
