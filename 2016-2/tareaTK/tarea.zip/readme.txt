Alexis Gavriel G�mez
2016085662
No se consideraron todos los casos de entrada para las validaciones, favor ingresar lo que se pide
En la parte 1 y 2 hay una barra a la derecha para bajar o subir en el cuadro de texto (donde se escribe la salida)