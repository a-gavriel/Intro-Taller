Version de python utilizada: 3.5.1
no se implemento el reloj en todas las ventanas
no se reconoce la victoria en el juego
no creo una forma de seguridad


alexis gavriel gomez
2016085662