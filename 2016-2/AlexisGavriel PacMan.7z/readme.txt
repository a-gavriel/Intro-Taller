version de python: 3.5
pygame para python 3.5
descarga de pygame:
http://www.lfd.uci.edu/~gohlke/pythonlibs/#pygame

autor:
Alexis Gavriel G�mez